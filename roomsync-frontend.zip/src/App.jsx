import { useState, useEffect, useCallback, useMemo } from "react";

// ─── CONSTANTS ──────────────────────────────────────────────────────────────

const ROOMS = [
  { id: 1, name: "Multi-Purpose Hall", size: "200 sqm", capacity: 200, rate: 287.50, color: "#E8F4FD", accent: "#1A73E8", icon: "🏛️" },
  { id: 2, name: "Video Conference Room", size: "80 sqm", capacity: 50, rate: 122.50, color: "#E8F8F0", accent: "#1B8C4E", icon: "🖥️" },
  { id: 3, name: "Middle Conference Room", size: "65 sqm", capacity: 30, rate: 103.73, color: "#FFF3E0", accent: "#E65C00", icon: "📋" },
];

const TICKET_PRIORITIES = ["Low", "Medium", "High", "Critical"];
const TICKET_STATUSES = ["Open", "In Progress", "Pending", "Resolved", "Closed"];
const BOOKING_STATUSES = ["Pending", "Confirmed", "Cancelled"];

const PRIORITY_COLORS = {
  Low: { bg: "#E8F5E9", text: "#2E7D32", border: "#A5D6A7" },
  Medium: { bg: "#FFF9C4", text: "#F57F17", border: "#FFE082" },
  High: { bg: "#FFF0E0", text: "#E65C00", border: "#FFCC80" },
  Critical: { bg: "#FFEBEE", text: "#C62828", border: "#EF9A9A" },
};

const STATUS_COLORS = {
  Open: { bg: "#E3F2FD", text: "#1565C0" },
  "In Progress": { bg: "#FFF9C4", text: "#F57F17" },
  Pending: { bg: "#F3E5F5", text: "#6A1B9A" },
  Resolved: { bg: "#E8F5E9", text: "#2E7D32" },
  Closed: { bg: "#F5F5F5", text: "#616161" },
  Confirmed: { bg: "#E8F5E9", text: "#2E7D32" },
  Cancelled: { bg: "#FFEBEE", text: "#C62828" },
};

// ─── BILLING LOGIC ───────────────────────────────────────────────────────────

function calcCost(roomId, attendees, startTime, endTime, externalParticipants) {
  const room = ROOMS.find(r => r.id === roomId);
  if (!room) return { cost: 0, duration: 0, billable: false };
  const [sh, sm] = startTime.split(":").map(Number);
  const [eh, em] = endTime.split(":").map(Number);
  const duration = (eh * 60 + em - sh * 60 - sm) / 60;
  if (duration <= 0) return { cost: 0, duration: 0, billable: false };
  const billable = externalParticipants === "Yes" || attendees > 20 || duration >= 4;
  const cost = billable ? room.rate * attendees * duration : 0;
  return { cost: parseFloat(cost.toFixed(2)), duration: parseFloat(duration.toFixed(2)), billable };
}

// ─── STORAGE HELPERS ─────────────────────────────────────────────────────────

function useLocalData() {
  const [bookings, setBookings] = useState(() => {
    try { return JSON.parse(localStorage.getItem("rs_bookings") || "[]"); } catch { return []; }
  });
  const [tickets, setTickets] = useState(() => {
    try { return JSON.parse(localStorage.getItem("rs_tickets") || "[]"); } catch { return []; }
  });
  const [users, setUsers] = useState(() => {
    try {
      const stored = JSON.parse(localStorage.getItem("rs_users") || "null");
      if (stored) return stored;
      return [
        { id: 1, name: "Admin User", email: "admin@roomsync.na", role: "Admin", password: "admin123", active: true },
        { id: 2, name: "Jane Editor", email: "editor@roomsync.na", role: "Editor", password: "editor123", active: true },
      ];
    } catch { return []; }
  });
  const [rooms, setRooms] = useState(() => {
    try { return JSON.parse(localStorage.getItem("rs_rooms") || JSON.stringify(ROOMS)); } catch { return ROOMS; }
  });
  const [logo, setLogo] = useState(() => localStorage.getItem("rs_logo") || null);

  const saveBookings = (b) => { setBookings(b); localStorage.setItem("rs_bookings", JSON.stringify(b)); };
  const saveTickets = (t) => { setTickets(t); localStorage.setItem("rs_tickets", JSON.stringify(t)); };
  const saveUsers = (u) => { setUsers(u); localStorage.setItem("rs_users", JSON.stringify(u)); };
  const saveRooms = (r) => { setRooms(r); localStorage.setItem("rs_rooms", JSON.stringify(r)); };
  const saveLogo = (l) => { setLogo(l); if (l) localStorage.setItem("rs_logo", l); else localStorage.removeItem("rs_logo"); };

  return { bookings, saveBookings, tickets, saveTickets, users, saveUsers, rooms, saveRooms, logo, saveLogo };
}

// ─── NOTIFICATION MOCK ────────────────────────────────────────────────────────

function simulateEmail(to, subject, body) {
  console.log(`📧 EMAIL TO: ${to}\nSUBJECT: ${subject}\n${body}`);
  return { sent: true, to, subject };
}

// ─── UI COMPONENTS ───────────────────────────────────────────────────────────

const styles = {
  app: { fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#F0F4FF", minHeight: "100vh", color: "#1A1A2E" },
  nav: { background: "linear-gradient(135deg, #1A73E8 0%, #0D47A1 100%)", color: "#fff", padding: "0 24px", display: "flex", alignItems: "center", height: 60, boxShadow: "0 2px 12px rgba(26,115,232,0.3)", position: "sticky", top: 0, zIndex: 100 },
  navBrand: { fontWeight: 700, fontSize: 20, letterSpacing: "-0.5px", display: "flex", alignItems: "center", gap: 10, cursor: "pointer" },
  navLinks: { display: "flex", gap: 4, marginLeft: 32, flex: 1, flexWrap: "wrap" },
  navLink: (active) => ({ padding: "6px 14px", borderRadius: 8, cursor: "pointer", fontSize: 14, fontWeight: active ? 600 : 400, background: active ? "rgba(255,255,255,0.2)" : "transparent", color: "#fff", border: "none", transition: "background 0.15s" }),
  navRight: { display: "flex", alignItems: "center", gap: 12 },
  badge: (color = "#1A73E8") => ({ background: color, color: "#fff", fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 12, letterSpacing: "0.5px" }),
  page: { maxWidth: 1200, margin: "0 auto", padding: "28px 20px" },
  card: { background: "#fff", borderRadius: 16, boxShadow: "0 1px 3px rgba(0,0,0,0.08)", padding: 24, marginBottom: 20 },
  cardSm: { background: "#fff", borderRadius: 12, boxShadow: "0 1px 3px rgba(0,0,0,0.07)", padding: 16 },
  h1: { fontSize: 28, fontWeight: 700, color: "#0D47A1", margin: "0 0 4px" },
  h2: { fontSize: 20, fontWeight: 700, color: "#1A237E", margin: "0 0 16px" },
  h3: { fontSize: 16, fontWeight: 600, color: "#283593", margin: "0 0 12px" },
  label: { display: "block", fontSize: 13, fontWeight: 600, color: "#374151", marginBottom: 5 },
  input: { width: "100%", padding: "9px 12px", border: "1.5px solid #D1D5DB", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box", transition: "border 0.15s", fontFamily: "inherit" },
  select: { width: "100%", padding: "9px 12px", border: "1.5px solid #D1D5DB", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box", background: "#fff", fontFamily: "inherit" },
  textarea: { width: "100%", padding: "9px 12px", border: "1.5px solid #D1D5DB", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box", minHeight: 90, resize: "vertical", fontFamily: "inherit" },
  btnPrimary: { background: "linear-gradient(135deg, #1A73E8, #0D47A1)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer", transition: "opacity 0.15s" },
  btnSecondary: { background: "#F0F4FF", color: "#1A73E8", border: "1.5px solid #1A73E8", borderRadius: 8, padding: "9px 18px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
  btnDanger: { background: "#FFEBEE", color: "#C62828", border: "1.5px solid #EF9A9A", borderRadius: 8, padding: "8px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" },
  btnSuccess: { background: "linear-gradient(135deg, #1B8C4E, #145C33)", color: "#fff", border: "none", borderRadius: 8, padding: "10px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer" },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 },
  grid3: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 },
  grid4: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 },
  formGroup: { marginBottom: 16 },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 14 },
  th: { background: "#F0F4FF", padding: "10px 12px", textAlign: "left", fontWeight: 600, fontSize: 13, color: "#374151", borderBottom: "2px solid #E3EAFF" },
  td: { padding: "12px 12px", borderBottom: "1px solid #F3F4F6", color: "#374151", verticalAlign: "middle" },
  statCard: (color) => ({ background: color, borderRadius: 12, padding: "20px 24px", flex: 1 }),
  tag: (bg, text, border) => ({ background: bg, color: text, border: `1px solid ${border || bg}`, fontSize: 12, fontWeight: 600, padding: "3px 10px", borderRadius: 12, display: "inline-block" }),
  alert: (type) => {
    const m = { success: { bg: "#E8F5E9", text: "#2E7D32", border: "#A5D6A7" }, error: { bg: "#FFEBEE", text: "#C62828", border: "#EF9A9A" }, info: { bg: "#E3F2FD", text: "#1565C0", border: "#90CAF9" }, warning: { bg: "#FFF9C4", text: "#F57F17", border: "#FFE082" } };
    const c = m[type] || m.info;
    return { background: c.bg, color: c.text, border: `1px solid ${c.border}`, borderRadius: 10, padding: "12px 16px", marginBottom: 16, fontSize: 14 };
  },
  modal: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 },
  modalBox: { background: "#fff", borderRadius: 20, padding: 32, width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 20px 60px rgba(0,0,0,0.2)" },
};

function Stat({ label, value, sub, color = "#E3F2FD", textColor = "#1565C0" }) {
  return (
    <div style={{ ...styles.statCard(color), minWidth: 120 }}>
      <div style={{ fontSize: 28, fontWeight: 700, color: textColor }}>{value}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: textColor, opacity: 0.85, marginTop: 2 }}>{label}</div>
      {sub && <div style={{ fontSize: 12, color: textColor, opacity: 0.65, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function Tag({ children, bg, text, border }) {
  return <span style={styles.tag(bg, text, border)}>{children}</span>;
}

function Modal({ title, children, onClose }) {
  return (
    <div style={styles.modal} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={styles.modalBox}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2 style={{ ...styles.h2, margin: 0 }}>{title}</h2>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#6B7280" }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Alert({ type, children }) {
  return <div style={styles.alert(type)}>{children}</div>;
}

// ─── CALENDAR COMPONENT ───────────────────────────────────────────────────────

function BookingCalendar({ bookings, rooms, onDateClick }) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

  const bookingsByDay = useMemo(() => {
    const map = {};
    bookings.filter(b => b.status !== "Cancelled").forEach(b => {
      const d = b.date;
      if (!map[d]) map[d] = [];
      map[d].push(b);
    });
    return map;
  }, [bookings]);

  const today = new Date().toISOString().split("T")[0];

  return (
    <div style={styles.card}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <h2 style={{ ...styles.h2, margin: 0 }}>📅 Availability Calendar</h2>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={() => setCurrentDate(new Date(year, month - 1))} style={styles.btnSecondary}>‹</button>
          <span style={{ fontWeight: 700, fontSize: 16, minWidth: 160, textAlign: "center" }}>{months[month]} {year}</span>
          <button onClick={() => setCurrentDate(new Date(year, month + 1))} style={styles.btnSecondary}>›</button>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 3, marginBottom: 8 }}>
        {days.map(d => <div key={d} style={{ textAlign: "center", fontSize: 12, fontWeight: 700, color: "#6B7280", padding: "6px 0" }}>{d}</div>)}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 3 }}>
        {Array(firstDay).fill(null).map((_, i) => <div key={`e${i}`} />)}
        {Array(daysInMonth).fill(null).map((_, i) => {
          const day = i + 1;
          const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
          const dayBookings = bookingsByDay[dateStr] || [];
          const isToday = dateStr === today;
          const hasBookings = dayBookings.length > 0;
          return (
            <div key={day} onClick={() => onDateClick(dateStr, dayBookings)}
              style={{ minHeight: 52, padding: 4, borderRadius: 8, cursor: "pointer", border: isToday ? "2px solid #1A73E8" : "1px solid #E5E7EB", background: hasBookings ? "#FFF3E0" : "#fff", transition: "background 0.15s", position: "relative" }}
              onMouseEnter={e => e.currentTarget.style.background = hasBookings ? "#FFE0B2" : "#F0F4FF"}
              onMouseLeave={e => e.currentTarget.style.background = hasBookings ? "#FFF3E0" : "#fff"}
            >
              <div style={{ fontSize: 13, fontWeight: isToday ? 700 : 400, color: isToday ? "#1A73E8" : "#374151" }}>{day}</div>
              {dayBookings.slice(0, 2).map((b, idx) => {
                const room = rooms.find(r => r.id === b.roomId);
                return (
                  <div key={idx} style={{ fontSize: 10, background: room?.accent || "#1A73E8", color: "#fff", borderRadius: 4, padding: "1px 4px", marginTop: 2, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
                    {b.startTime} {room?.name?.split(" ")[0]}
                  </div>
                );
              })}
              {dayBookings.length > 2 && <div style={{ fontSize: 10, color: "#E65C00", fontWeight: 600 }}>+{dayBookings.length - 2} more</div>}
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}><div style={{ width: 12, height: 12, background: "#FFF3E0", border: "1px solid #D1D5DB", borderRadius: 3 }} />Has bookings</div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}><div style={{ width: 12, height: 12, background: "#fff", border: "2px solid #1A73E8", borderRadius: 3 }} />Today</div>
      </div>
    </div>
  );
}

// ─── BOOKING FORM ─────────────────────────────────────────────────────────────

function BookingForm({ rooms, bookings, onSubmit, currentUser }) {
  const [form, setForm] = useState({ name: currentUser?.name || "", email: currentUser?.email || "", agency: "", roomId: "", date: "", startTime: "", endTime: "", attendees: "", externalParticipants: "No", notes: "" });
  const [msg, setMsg] = useState(null);
  const [conflicts, setConflicts] = useState([]);

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const costInfo = useMemo(() => {
    if (!form.roomId || !form.startTime || !form.endTime || !form.attendees) return null;
    return calcCost(Number(form.roomId), Number(form.attendees), form.startTime, form.endTime, form.externalParticipants);
  }, [form.roomId, form.startTime, form.endTime, form.attendees, form.externalParticipants]);

  const checkConflicts = useCallback(() => {
    if (!form.roomId || !form.date || !form.startTime || !form.endTime) return [];
    const toMin = t => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
    const newStart = toMin(form.startTime);
    const newEnd = toMin(form.endTime);
    return bookings.filter(b => b.roomId === Number(form.roomId) && b.date === form.date && b.status !== "Cancelled" && toMin(b.startTime) < newEnd && toMin(b.endTime) > newStart);
  }, [form, bookings]);

  useEffect(() => { setConflicts(checkConflicts()); }, [checkConflicts]);

  const handleSubmit = () => {
    const required = ["name", "email", "agency", "roomId", "date", "startTime", "endTime", "attendees"];
    for (const k of required) if (!form[k]) { setMsg({ type: "error", text: "Please fill all required fields." }); return; }
    if (conflicts.length > 0) { setMsg({ type: "error", text: "This time slot conflicts with existing bookings." }); return; }
    if (costInfo && costInfo.duration <= 0) { setMsg({ type: "error", text: "End time must be after start time." }); return; }

    const booking = { ...form, roomId: Number(form.roomId), attendees: Number(form.attendees), id: Date.now(), status: "Confirmed", createdAt: new Date().toISOString(), cost: costInfo?.cost || 0, duration: costInfo?.duration || 0 };
    onSubmit(booking);
    const room = rooms.find(r => r.id === booking.roomId);
    simulateEmail(booking.email, "Booking Confirmation – " + room?.name, `Dear ${booking.name},\nYour booking is confirmed.\nRoom: ${room?.name}\nDate: ${booking.date}\nTime: ${booking.startTime}–${booking.endTime}\nAttendees: ${booking.attendees}\nCost: N$${booking.cost.toFixed(2)}\nAgency: ${booking.agency}`);
    setMsg({ type: "success", text: `Booking confirmed! ${costInfo?.cost > 0 ? `Cost: N$${costInfo.cost.toFixed(2)}` : "No charge applies."}` });
    setForm({ name: "", email: "", agency: "", roomId: "", date: "", startTime: "", endTime: "", attendees: "", externalParticipants: "No", notes: "" });
  };

  return (
    <div style={styles.card}>
      <h2 style={styles.h2}>📝 Book a Room</h2>
      {msg && <Alert type={msg.type}>{msg.text}</Alert>}
      {conflicts.length > 0 && (
        <Alert type="error">⚠️ Conflict! This room is already booked at this time: {conflicts.map(c => `${c.startTime}–${c.endTime} by ${c.name}`).join(", ")}</Alert>
      )}
      <div style={styles.grid2}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Full Name *</label>
          <input style={styles.input} value={form.name} onChange={e => setField("name", e.target.value)} placeholder="Your full name" />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>Email Address *</label>
          <input style={styles.input} type="email" value={form.email} onChange={e => setField("email", e.target.value)} placeholder="you@example.com" />
        </div>
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Agency / Organisation *</label>
        <input style={styles.input} value={form.agency} onChange={e => setField("agency", e.target.value)} placeholder="Your agency or organisation name" />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Select Room *</label>
        <select style={styles.select} value={form.roomId} onChange={e => setField("roomId", e.target.value)}>
          <option value="">— Choose a room —</option>
          {rooms.map(r => <option key={r.id} value={r.id}>{r.icon} {r.name} ({r.size}) — N${r.rate}/person/hr</option>)}
        </select>
      </div>
      <div style={styles.grid3}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Date *</label>
          <input style={styles.input} type="date" value={form.date} min={new Date().toISOString().split("T")[0]} onChange={e => setField("date", e.target.value)} />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>Start Time *</label>
          <input style={styles.input} type="time" value={form.startTime} onChange={e => setField("startTime", e.target.value)} />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>End Time *</label>
          <input style={styles.input} type="time" value={form.endTime} onChange={e => setField("endTime", e.target.value)} />
        </div>
      </div>
      <div style={styles.grid2}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Number of Attendees *</label>
          <input style={styles.input} type="number" min="1" value={form.attendees} onChange={e => setField("attendees", e.target.value)} placeholder="e.g. 15" />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>External Participants? *</label>
          <select style={styles.select} value={form.externalParticipants} onChange={e => setField("externalParticipants", e.target.value)}>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </div>
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Additional Notes</label>
        <textarea style={styles.textarea} value={form.notes} onChange={e => setField("notes", e.target.value)} placeholder="Any special requirements or notes..." />
      </div>

      {costInfo && (
        <div style={{ background: costInfo.billable ? "#FFF3E0" : "#E8F5E9", border: `1px solid ${costInfo.billable ? "#FFB74D" : "#81C784"}`, borderRadius: 12, padding: 16, marginBottom: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: costInfo.billable ? "#E65C00" : "#2E7D32", marginBottom: 8 }}>
            {costInfo.billable ? "💰 Billable Booking" : "✅ No Charge Applies"}
          </div>
          <div style={{ display: "flex", gap: 24, fontSize: 13, flexWrap: "wrap" }}>
            <span><strong>Duration:</strong> {costInfo.duration.toFixed(1)} hrs</span>
            <span><strong>Attendees:</strong> {form.attendees}</span>
            <span><strong>Rate:</strong> N${rooms.find(r => r.id === Number(form.roomId))?.rate}/person/hr</span>
            {costInfo.billable && <span style={{ fontWeight: 700, fontSize: 16 }}><strong>Total Cost: N${costInfo.cost.toFixed(2)}</strong></span>}
          </div>
          {costInfo.billable && (
            <div style={{ fontSize: 12, color: "#6B7280", marginTop: 8 }}>
              Charged because: {[form.externalParticipants === "Yes" && "external participants", Number(form.attendees) > 20 && ">20 attendees", costInfo.duration >= 4 && "≥4 hour duration"].filter(Boolean).join(", ")}
            </div>
          )}
        </div>
      )}

      <button style={styles.btnPrimary} onClick={handleSubmit}>Submit Booking Request</button>
    </div>
  );
}

// ─── TICKET FORM ──────────────────────────────────────────────────────────────

function TicketForm({ onSubmit, users }) {
  const [form, setForm] = useState({ name: "", email: "", subject: "", description: "", priority: "Medium", category: "General" });
  const [msg, setMsg] = useState(null);
  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    if (!form.name || !form.email || !form.subject || !form.description) { setMsg({ type: "error", text: "Please fill all required fields." }); return; }
    const ticket = { ...form, id: Date.now(), status: "Open", createdAt: new Date().toISOString(), assignedTo: null, updates: [] };
    onSubmit(ticket);
    simulateEmail(form.email, "Ticket Received – " + form.subject, `Dear ${form.name},\nYour support ticket has been received.\nTicket ID: #${ticket.id}\nPriority: ${form.priority}\nWe'll be in touch soon.`);
    setMsg({ type: "success", text: "Your ticket has been submitted! You'll receive a confirmation email." });
    setForm({ name: "", email: "", subject: "", description: "", priority: "Medium", category: "General" });
  };

  return (
    <div style={styles.card}>
      <h2 style={styles.h2}>🎫 Submit a Support Ticket</h2>
      {msg && <Alert type={msg.type}>{msg.text}</Alert>}
      <div style={styles.grid2}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Your Name *</label>
          <input style={styles.input} value={form.name} onChange={e => setField("name", e.target.value)} placeholder="Full name" />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>Email Address *</label>
          <input style={styles.input} type="email" value={form.email} onChange={e => setField("email", e.target.value)} placeholder="you@example.com" />
        </div>
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Subject *</label>
        <input style={styles.input} value={form.subject} onChange={e => setField("subject", e.target.value)} placeholder="Brief description of the issue" />
      </div>
      <div style={styles.grid2}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Priority</label>
          <select style={styles.select} value={form.priority} onChange={e => setField("priority", e.target.value)}>
            {TICKET_PRIORITIES.map(p => <option key={p}>{p}</option>)}
          </select>
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>Category</label>
          <select style={styles.select} value={form.category} onChange={e => setField("category", e.target.value)}>
            {["General", "Technical", "Billing", "Access", "Maintenance", "Other"].map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Description *</label>
        <textarea style={styles.textarea} value={form.description} onChange={e => setField("description", e.target.value)} placeholder="Please describe your issue in detail..." />
      </div>
      <button style={styles.btnPrimary} onClick={handleSubmit}>Submit Ticket</button>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────

function Dashboard({ bookings, tickets, rooms }) {
  const now = new Date();
  const thisMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

  const monthBookings = bookings.filter(b => b.createdAt?.startsWith(thisMonth));
  const monthRevenue = monthBookings.reduce((s, b) => s + (b.cost || 0), 0);
  const openTickets = tickets.filter(t => !["Resolved", "Closed"].includes(t.status));
  const criticalTickets = tickets.filter(t => t.priority === "Critical" && !["Resolved", "Closed"].includes(t.status));

  const roomStats = rooms.map(r => ({
    ...r,
    count: bookings.filter(b => b.roomId === r.id && b.status === "Confirmed").length,
    revenue: bookings.filter(b => b.roomId === r.id).reduce((s, b) => s + (b.cost || 0), 0),
  }));

  const recentBookings = [...bookings].sort((a, b) => b.createdAt?.localeCompare(a.createdAt)).slice(0, 5);
  const recentTickets = [...tickets].sort((a, b) => b.createdAt?.localeCompare(a.createdAt)).slice(0, 5);

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={styles.h1}>📊 Dashboard</h1>
        <p style={{ color: "#6B7280", margin: 0 }}>Overview for {now.toLocaleDateString("en-NA", { month: "long", year: "numeric" })}</p>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        <Stat label="Total Bookings" value={bookings.length} sub={`${monthBookings.length} this month`} color="#E3F2FD" textColor="#1565C0" />
        <Stat label="Monthly Revenue" value={`N$${monthRevenue.toLocaleString(undefined, {maximumFractionDigits:2})}`} color="#E8F5E9" textColor="#2E7D32" />
        <Stat label="Open Tickets" value={openTickets.length} sub={`${criticalTickets.length} critical`} color="#FFF3E0" textColor="#E65C00" />
        <Stat label="Active Rooms" value={rooms.length} color="#F3E5F5" textColor="#6A1B9A" />
      </div>

      <div style={styles.grid3}>
        {roomStats.map(r => (
          <div key={r.id} style={{ ...styles.cardSm, borderLeft: `4px solid ${r.accent}` }}>
            <div style={{ fontSize: 18 }}>{r.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 14, marginTop: 4 }}>{r.name}</div>
            <div style={{ fontSize: 12, color: "#6B7280" }}>{r.size}</div>
            <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 13 }}><strong>{r.count}</strong> bookings</span>
              <span style={{ fontSize: 13, color: "#2E7D32", fontWeight: 600 }}>N${r.revenue.toFixed(0)}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={styles.grid2}>
        <div style={styles.card}>
          <h3 style={styles.h3}>Recent Bookings</h3>
          {recentBookings.length === 0 ? <p style={{ color: "#9CA3AF", fontSize: 14 }}>No bookings yet.</p> : (
            recentBookings.map(b => {
              const room = rooms.find(r => r.id === b.roomId);
              return (
                <div key={b.id} style={{ padding: "10px 0", borderBottom: "1px solid #F3F4F6", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{b.name}</div>
                    <div style={{ fontSize: 12, color: "#6B7280" }}>{room?.name} · {b.date}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <Tag {...(STATUS_COLORS[b.status] || {})} bg={STATUS_COLORS[b.status]?.bg} text={STATUS_COLORS[b.status]?.text}>{b.status}</Tag>
                    {b.cost > 0 && <div style={{ fontSize: 12, color: "#2E7D32", fontWeight: 600, marginTop: 2 }}>N${b.cost.toFixed(2)}</div>}
                  </div>
                </div>
              );
            })
          )}
        </div>
        <div style={styles.card}>
          <h3 style={styles.h3}>Recent Tickets</h3>
          {recentTickets.length === 0 ? <p style={{ color: "#9CA3AF", fontSize: 14 }}>No tickets yet.</p> : (
            recentTickets.map(t => (
              <div key={t.id} style={{ padding: "10px 0", borderBottom: "1px solid #F3F4F6", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{t.subject}</div>
                  <div style={{ fontSize: 12, color: "#6B7280" }}>{t.name} · {new Date(t.createdAt).toLocaleDateString()}</div>
                </div>
                <div style={{ textAlign: "right", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                  <Tag {...PRIORITY_COLORS[t.priority]}>{t.priority}</Tag>
                  <Tag bg={STATUS_COLORS[t.status]?.bg} text={STATUS_COLORS[t.status]?.text}>{t.status}</Tag>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

// ─── BOOKINGS TABLE ────────────────────────────────────────────────────────────

function BookingsPage({ bookings, saveBookings, rooms, currentUser }) {
  const [filter, setFilter] = useState({ status: "", room: "", month: "" });
  const [selected, setSelected] = useState(null);
  const [showInvoice, setShowInvoice] = useState(false);
  const [invoiceAgency, setInvoiceAgency] = useState("");
  const [invoiceMonth, setInvoiceMonth] = useState(new Date().toISOString().slice(0, 7));

  const isPrivileged = currentUser && ["Admin", "Editor"].includes(currentUser.role);

  const filtered = bookings.filter(b =>
    (!filter.status || b.status === filter.status) &&
    (!filter.room || b.roomId === Number(filter.room)) &&
    (!filter.month || b.date?.startsWith(filter.month))
  );

  const updateStatus = (id, status) => {
    saveBookings(bookings.map(b => b.id === id ? { ...b, status } : b));
  };

  const agencies = [...new Set(bookings.map(b => b.agency))].filter(Boolean);

  const invoiceData = useMemo(() => {
    if (!invoiceAgency || !invoiceMonth) return null;
    const agencyBookings = bookings.filter(b => b.agency === invoiceAgency && b.date?.startsWith(invoiceMonth) && b.status === "Confirmed");
    const total = agencyBookings.reduce((s, b) => s + (b.cost || 0), 0);
    return { bookings: agencyBookings, total, agency: invoiceAgency, month: invoiceMonth };
  }, [bookings, invoiceAgency, invoiceMonth]);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h1 style={styles.h1}>📅 Room Bookings</h1>
        {isPrivileged && <button style={styles.btnSuccess} onClick={() => setShowInvoice(true)}>📄 Generate Invoice</button>}
      </div>

      <div style={styles.card}>
        <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
          <select style={{ ...styles.select, width: "auto", minWidth: 140 }} value={filter.status} onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}>
            <option value="">All Statuses</option>
            {BOOKING_STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
          <select style={{ ...styles.select, width: "auto", minWidth: 180 }} value={filter.room} onChange={e => setFilter(f => ({ ...f, room: e.target.value }))}>
            <option value="">All Rooms</option>
            {rooms.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
          <input type="month" style={{ ...styles.input, width: "auto" }} value={filter.month} onChange={e => setFilter(f => ({ ...f, month: e.target.value }))} />
        </div>

        <div style={{ overflowX: "auto" }}>
          <table style={styles.table}>
            <thead>
              <tr>
                {["Name", "Agency", "Room", "Date", "Time", "Attendees", "Cost", "Status", isPrivileged ? "Actions" : ""].map(h => <th key={h} style={styles.th}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={9} style={{ ...styles.td, textAlign: "center", color: "#9CA3AF" }}>No bookings found.</td></tr>
              ) : filtered.map(b => {
                const room = rooms.find(r => r.id === b.roomId);
                return (
                  <tr key={b.id} onClick={() => setSelected(b)} style={{ cursor: "pointer" }} onMouseEnter={e => e.currentTarget.style.background = "#F8FAFF"} onMouseLeave={e => e.currentTarget.style.background = ""}>
                    <td style={styles.td}><div style={{ fontWeight: 600 }}>{b.name}</div><div style={{ fontSize: 12, color: "#6B7280" }}>{b.email}</div></td>
                    <td style={styles.td}>{b.agency}</td>
                    <td style={styles.td}><span style={{ fontSize: 12 }}>{room?.icon} {room?.name}</span></td>
                    <td style={styles.td}>{b.date}</td>
                    <td style={styles.td}>{b.startTime}–{b.endTime}</td>
                    <td style={styles.td}>{b.attendees}</td>
                    <td style={styles.td}><span style={{ fontWeight: 600, color: b.cost > 0 ? "#2E7D32" : "#9CA3AF" }}>{b.cost > 0 ? `N$${b.cost.toFixed(2)}` : "Free"}</span></td>
                    <td style={styles.td}><Tag bg={STATUS_COLORS[b.status]?.bg} text={STATUS_COLORS[b.status]?.text}>{b.status}</Tag></td>
                    {isPrivileged && (
                      <td style={styles.td} onClick={e => e.stopPropagation()}>
                        <select style={{ ...styles.select, width: 130, fontSize: 12, padding: "4px 8px" }} value={b.status} onChange={e => updateStatus(b.id, e.target.value)}>
                          {BOOKING_STATUSES.map(s => <option key={s}>{s}</option>)}
                        </select>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selected && (
        <Modal title="Booking Details" onClose={() => setSelected(null)}>
          <div style={{ display: "grid", gap: 10 }}>
            {[["Name", selected.name], ["Email", selected.email], ["Agency", selected.agency], ["Room", rooms.find(r => r.id === selected.roomId)?.name], ["Date", selected.date], ["Time", `${selected.startTime} – ${selected.endTime}`], ["Duration", `${selected.duration} hrs`], ["Attendees", selected.attendees], ["External Participants", selected.externalParticipants], ["Cost", selected.cost > 0 ? `N$${selected.cost.toFixed(2)}` : "No charge"], ["Status", selected.status], ["Notes", selected.notes || "—"]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", gap: 16 }}>
                <span style={{ fontSize: 13, color: "#6B7280", minWidth: 130, fontWeight: 600 }}>{k}</span>
                <span style={{ fontSize: 14 }}>{v}</span>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {showInvoice && (
        <Modal title="Generate Monthly Invoice" onClose={() => setShowInvoice(false)}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Agency</label>
            <select style={styles.select} value={invoiceAgency} onChange={e => setInvoiceAgency(e.target.value)}>
              <option value="">— Select Agency —</option>
              {agencies.map(a => <option key={a}>{a}</option>)}
            </select>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Month</label>
            <input type="month" style={styles.input} value={invoiceMonth} onChange={e => setInvoiceMonth(e.target.value)} />
          </div>
          {invoiceData && (
            <div style={{ background: "#F8FAFF", borderRadius: 10, padding: 16, marginTop: 16 }}>
              <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12 }}>Invoice Preview – {invoiceData.agency}</div>
              <table style={styles.table}>
                <thead><tr><th style={styles.th}>Room</th><th style={styles.th}>Date</th><th style={styles.th}>Duration</th><th style={styles.th}>Attendees</th><th style={styles.th}>Cost</th></tr></thead>
                <tbody>
                  {invoiceData.bookings.map(b => {
                    const room = rooms.find(r => r.id === b.roomId);
                    return <tr key={b.id}><td style={styles.td}>{room?.name}</td><td style={styles.td}>{b.date}</td><td style={styles.td}>{b.duration}h</td><td style={styles.td}>{b.attendees}</td><td style={styles.td}>N${b.cost.toFixed(2)}</td></tr>;
                  })}
                </tbody>
              </table>
              <div style={{ textAlign: "right", marginTop: 12, fontWeight: 700, fontSize: 18, color: "#2E7D32" }}>Total: N${invoiceData.total.toFixed(2)}</div>
              <button style={{ ...styles.btnPrimary, marginTop: 12, width: "100%" }} onClick={() => { alert(`Invoice generated for ${invoiceData.agency}: N$${invoiceData.total.toFixed(2)}`); }}>
                📥 Download Invoice (PDF)
              </button>
            </div>
          )}
          {invoiceData && invoiceData.bookings.length === 0 && <Alert type="info">No confirmed billable bookings for {invoiceAgency} in {invoiceMonth}.</Alert>}
        </Modal>
      )}
    </div>
  );
}

// ─── TICKETS PAGE ──────────────────────────────────────────────────────────────

function TicketsPage({ tickets, saveTickets, users, currentUser }) {
  const [filter, setFilter] = useState({ status: "", priority: "" });
  const [selected, setSelected] = useState(null);
  const [note, setNote] = useState("");

  const isPrivileged = currentUser && ["Admin", "Editor"].includes(currentUser.role);

  const filtered = tickets.filter(t =>
    (!filter.status || t.status === filter.status) &&
    (!filter.priority || t.priority === filter.priority)
  );

  const updateTicket = (id, updates) => {
    saveTickets(tickets.map(t => t.id === id ? { ...t, ...updates } : t));
    if (selected?.id === id) setSelected(s => ({ ...s, ...updates }));
  };

  const addNote = () => {
    if (!note.trim()) return;
    const updates = [{ text: note, by: currentUser?.name || "Staff", at: new Date().toISOString() }, ...(selected.updates || [])];
    updateTicket(selected.id, { updates });
    setNote("");
  };

  const staffUsers = users.filter(u => ["Admin", "Editor"].includes(u.role) && u.active);

  return (
    <div>
      <h1 style={{ ...styles.h1, marginBottom: 20 }}>🎫 Support Tickets</h1>

      <div style={styles.card}>
        <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
          <select style={{ ...styles.select, width: "auto", minWidth: 140 }} value={filter.status} onChange={e => setFilter(f => ({ ...f, status: e.target.value }))}>
            <option value="">All Statuses</option>
            {TICKET_STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
          <select style={{ ...styles.select, width: "auto", minWidth: 140 }} value={filter.priority} onChange={e => setFilter(f => ({ ...f, priority: e.target.value }))}>
            <option value="">All Priorities</option>
            {TICKET_PRIORITIES.map(p => <option key={p}>{p}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
          {TICKET_STATUSES.map(s => {
            const count = tickets.filter(t => t.status === s).length;
            return <div key={s} style={{ ...styles.tag(STATUS_COLORS[s]?.bg || "#F5F5F5", STATUS_COLORS[s]?.text || "#616161"), cursor: "pointer" }} onClick={() => setFilter(f => ({ ...f, status: f.status === s ? "" : s }))}>{s}: {count}</div>;
          })}
        </div>

        <div style={{ overflowX: "auto" }}>
          <table style={styles.table}>
            <thead>
              <tr>{["#", "Subject", "Submitted By", "Category", "Priority", "Status", "Assigned To", "Date", isPrivileged ? "Actions" : ""].map(h => <th key={h} style={styles.th}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={9} style={{ ...styles.td, textAlign: "center", color: "#9CA3AF" }}>No tickets found.</td></tr>
              ) : filtered.map(t => (
                <tr key={t.id} onClick={() => setSelected(t)} style={{ cursor: "pointer" }} onMouseEnter={e => e.currentTarget.style.background = "#F8FAFF"} onMouseLeave={e => e.currentTarget.style.background = ""}>
                  <td style={styles.td}><span style={{ fontSize: 11, fontFamily: "monospace", color: "#6B7280" }}>#{String(t.id).slice(-6)}</span></td>
                  <td style={styles.td}><div style={{ fontWeight: 600 }}>{t.subject}</div></td>
                  <td style={styles.td}><div style={{ fontSize: 13 }}>{t.name}</div><div style={{ fontSize: 11, color: "#6B7280" }}>{t.email}</div></td>
                  <td style={styles.td}>{t.category}</td>
                  <td style={styles.td}><Tag {...PRIORITY_COLORS[t.priority]}>{t.priority}</Tag></td>
                  <td style={styles.td}><Tag bg={STATUS_COLORS[t.status]?.bg} text={STATUS_COLORS[t.status]?.text}>{t.status}</Tag></td>
                  <td style={styles.td}>{t.assignedTo || <span style={{ color: "#9CA3AF" }}>Unassigned</span>}</td>
                  <td style={styles.td}>{new Date(t.createdAt).toLocaleDateString()}</td>
                  {isPrivileged && (
                    <td style={styles.td} onClick={e => e.stopPropagation()}>
                      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                        <select style={{ ...styles.select, width: 120, fontSize: 11, padding: "3px 6px" }} value={t.status} onChange={e => updateTicket(t.id, { status: e.target.value })}>
                          {TICKET_STATUSES.map(s => <option key={s}>{s}</option>)}
                        </select>
                        <select style={{ ...styles.select, width: 130, fontSize: 11, padding: "3px 6px" }} value={t.assignedTo || ""} onChange={e => updateTicket(t.id, { assignedTo: e.target.value })}>
                          <option value="">Unassigned</option>
                          {staffUsers.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                        </select>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selected && (
        <Modal title={`Ticket: ${selected.subject}`} onClose={() => setSelected(null)}>
          <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
            <Tag {...PRIORITY_COLORS[selected.priority]}>{selected.priority} Priority</Tag>
            <Tag bg={STATUS_COLORS[selected.status]?.bg} text={STATUS_COLORS[selected.status]?.text}>{selected.status}</Tag>
            {selected.assignedTo && <Tag bg="#E3F2FD" text="#1565C0">Assigned: {selected.assignedTo}</Tag>}
          </div>
          <div style={{ background: "#F8FAFF", borderRadius: 10, padding: 14, marginBottom: 16 }}>
            <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 4 }}>From: {selected.name} ({selected.email}) · {new Date(selected.createdAt).toLocaleString()}</div>
            <div style={{ fontSize: 14 }}>{selected.description}</div>
          </div>
          {isPrivileged && (
            <div style={{ marginBottom: 16 }}>
              <div style={styles.grid2}>
                <div>
                  <label style={styles.label}>Update Status</label>
                  <select style={styles.select} value={selected.status} onChange={e => updateTicket(selected.id, { status: e.target.value })}>
                    {TICKET_STATUSES.map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label style={styles.label}>Assign To</label>
                  <select style={styles.select} value={selected.assignedTo || ""} onChange={e => updateTicket(selected.id, { assignedTo: e.target.value })}>
                    <option value="">Unassigned</option>
                    {staffUsers.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ marginTop: 12 }}>
                <label style={styles.label}>Add Note</label>
                <div style={{ display: "flex", gap: 8 }}>
                  <input style={{ ...styles.input, flex: 1 }} value={note} onChange={e => setNote(e.target.value)} placeholder="Internal note..." />
                  <button style={styles.btnPrimary} onClick={addNote}>Add</button>
                </div>
              </div>
            </div>
          )}
          {(selected.updates || []).length > 0 && (
            <div>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8 }}>Activity Log</div>
              {(selected.updates || []).map((u, i) => (
                <div key={i} style={{ padding: "8px 12px", background: "#F8FAFF", borderRadius: 8, marginBottom: 6, fontSize: 13 }}>
                  <span style={{ fontWeight: 600 }}>{u.by}</span> · <span style={{ color: "#6B7280" }}>{new Date(u.at).toLocaleString()}</span>
                  <div style={{ marginTop: 4 }}>{u.text}</div>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

// ─── REPORTS PAGE ─────────────────────────────────────────────────────────────

function ReportsPage({ bookings, tickets, rooms }) {
  const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7));

  const monthBookings = bookings.filter(b => b.date?.startsWith(reportMonth));
  const monthTickets = tickets.filter(t => t.createdAt?.startsWith(reportMonth));

  const byRoom = rooms.map(r => ({
    ...r,
    bookings: monthBookings.filter(b => b.roomId === r.id),
    revenue: monthBookings.filter(b => b.roomId === r.id).reduce((s, b) => s + (b.cost || 0), 0),
  }));

  const byStatus = BOOKING_STATUSES.reduce((acc, s) => { acc[s] = monthBookings.filter(b => b.status === s).length; return acc; }, {});
  const byPriority = TICKET_PRIORITIES.reduce((acc, p) => { acc[p] = monthTickets.filter(t => t.priority === p).length; return acc; }, {});

  const agencies = [...new Set(monthBookings.map(b => b.agency))].filter(Boolean);
  const agencyStats = agencies.map(a => ({
    agency: a,
    count: monthBookings.filter(b => b.agency === a).length,
    revenue: monthBookings.filter(b => b.agency === a).reduce((s, b) => s + (b.cost || 0), 0),
  })).sort((a, b) => b.revenue - a.revenue);

  const totalRevenue = monthBookings.reduce((s, b) => s + (b.cost || 0), 0);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h1 style={styles.h1}>📈 Monthly Reports</h1>
        <input type="month" style={{ ...styles.input, width: 180 }} value={reportMonth} onChange={e => setReportMonth(e.target.value)} />
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        <Stat label="Total Bookings" value={monthBookings.length} color="#E3F2FD" textColor="#1565C0" />
        <Stat label="Total Revenue" value={`N$${totalRevenue.toFixed(2)}`} color="#E8F5E9" textColor="#2E7D32" />
        <Stat label="Tickets Created" value={monthTickets.length} color="#FFF3E0" textColor="#E65C00" />
        <Stat label="Resolved Tickets" value={monthTickets.filter(t => t.status === "Resolved").length} color="#F3E5F5" textColor="#6A1B9A" />
      </div>

      <div style={styles.grid2}>
        <div style={styles.card}>
          <h3 style={styles.h3}>Room Performance</h3>
          {byRoom.map(r => (
            <div key={r.id} style={{ padding: "12px 0", borderBottom: "1px solid #F3F4F6" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontWeight: 600 }}>{r.icon} {r.name}</span>
                <span style={{ color: "#2E7D32", fontWeight: 600 }}>N${r.revenue.toFixed(2)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#6B7280" }}>
                <span>{r.bookings.length} bookings</span>
                <div style={{ height: 6, flex: 1, background: "#F3F4F6", borderRadius: 3, margin: "0 10px", alignSelf: "center" }}>
                  <div style={{ height: "100%", width: `${monthBookings.length ? (r.bookings.length / monthBookings.length) * 100 : 0}%`, background: r.accent, borderRadius: 3 }} />
                </div>
                <span>{monthBookings.length ? Math.round((r.bookings.length / monthBookings.length) * 100) : 0}%</span>
              </div>
            </div>
          ))}
        </div>

        <div style={styles.card}>
          <h3 style={styles.h3}>Agency Revenue</h3>
          {agencyStats.length === 0 ? <p style={{ color: "#9CA3AF", fontSize: 14 }}>No data for this month.</p> : agencyStats.map(a => (
            <div key={a.agency} style={{ padding: "10px 0", borderBottom: "1px solid #F3F4F6" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontWeight: 600, fontSize: 14 }}>{a.agency}</span>
                <span style={{ color: "#2E7D32", fontWeight: 600 }}>N${a.revenue.toFixed(2)}</span>
              </div>
              <span style={{ fontSize: 12, color: "#6B7280" }}>{a.count} booking{a.count !== 1 ? "s" : ""}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={styles.grid2}>
        <div style={styles.card}>
          <h3 style={styles.h3}>Booking Status Breakdown</h3>
          {Object.entries(byStatus).map(([s, c]) => (
            <div key={s} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #F3F4F6", alignItems: "center" }}>
              <Tag bg={STATUS_COLORS[s]?.bg} text={STATUS_COLORS[s]?.text}>{s}</Tag>
              <span style={{ fontWeight: 600 }}>{c}</span>
            </div>
          ))}
        </div>
        <div style={styles.card}>
          <h3 style={styles.h3}>Ticket Priority Breakdown</h3>
          {Object.entries(byPriority).map(([p, c]) => (
            <div key={p} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #F3F4F6", alignItems: "center" }}>
              <Tag {...PRIORITY_COLORS[p]}>{p}</Tag>
              <span style={{ fontWeight: 600 }}>{c}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── SETTINGS PAGE ────────────────────────────────────────────────────────────

function SettingsPage({ users, saveUsers, rooms, saveRooms, logo, saveLogo, currentUser }) {
  const [tab, setTab] = useState("rooms");
  const [editingRoom, setEditingRoom] = useState(null);
  const [editingUser, setEditingUser] = useState(null);
  const [newRoom, setNewRoom] = useState({ name: "", size: "", capacity: "", rate: "", icon: "🏢" });
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "Editor", password: "", active: true });
  const [msg, setMsg] = useState(null);

  if (currentUser?.role !== "Admin") return <Alert type="error">Access denied. Admin privileges required.</Alert>;

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => saveLogo(ev.target.result);
    reader.readAsDataURL(file);
  };

  const saveRoom = () => {
    if (!newRoom.name || !newRoom.rate) { setMsg({ type: "error", text: "Name and rate are required." }); return; }
    if (editingRoom) {
      saveRooms(rooms.map(r => r.id === editingRoom.id ? { ...r, ...newRoom, rate: Number(newRoom.rate), capacity: Number(newRoom.capacity) } : r));
    } else {
      saveRooms([...rooms, { ...newRoom, id: Date.now(), rate: Number(newRoom.rate), capacity: Number(newRoom.capacity), color: "#E8F4FD", accent: "#1A73E8" }]);
    }
    setNewRoom({ name: "", size: "", capacity: "", rate: "", icon: "🏢" });
    setEditingRoom(null);
    setMsg({ type: "success", text: "Room saved." });
  };

  const deleteRoom = (id) => { if (window.confirm("Delete this room?")) saveRooms(rooms.filter(r => r.id !== id)); };

  const saveUser = () => {
    if (!newUser.name || !newUser.email) { setMsg({ type: "error", text: "Name and email required." }); return; }
    if (editingUser) {
      saveUsers(users.map(u => u.id === editingUser.id ? { ...u, ...newUser } : u));
    } else {
      if (!newUser.password) { setMsg({ type: "error", text: "Password required." }); return; }
      saveUsers([...users, { ...newUser, id: Date.now() }]);
    }
    setNewUser({ name: "", email: "", role: "Editor", password: "", active: true });
    setEditingUser(null);
    setMsg({ type: "success", text: "User saved." });
  };

  const deleteUser = (id) => { if (id === currentUser.id) { alert("Cannot delete yourself."); return; } if (window.confirm("Delete user?")) saveUsers(users.filter(u => u.id !== id)); };

  return (
    <div>
      <h1 style={{ ...styles.h1, marginBottom: 20 }}>⚙️ Settings</h1>
      {msg && <Alert type={msg.type}>{msg.text}</Alert>}

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {["rooms", "users", "branding"].map(t => (
          <button key={t} style={tab === t ? styles.btnPrimary : styles.btnSecondary} onClick={() => setTab(t)}>
            {t === "rooms" ? "🏢 Rooms" : t === "users" ? "👥 Users" : "🎨 Branding"}
          </button>
        ))}
      </div>

      {tab === "branding" && (
        <div style={styles.card}>
          <h2 style={styles.h2}>Logo & Branding</h2>
          <div style={{ display: "flex", gap: 20, alignItems: "center", marginBottom: 20 }}>
            <div style={{ width: 120, height: 80, background: "#F0F4FF", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", border: "1px dashed #CBD5E1" }}>
              {logo ? <img src={logo} alt="Logo" style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} /> : <span style={{ fontSize: 32 }}>🏢</span>}
            </div>
            <div>
              <label style={styles.label}>Upload Logo</label>
              <input type="file" accept="image/*" onChange={handleLogoChange} style={{ fontSize: 14 }} />
              {logo && <button style={{ ...styles.btnDanger, marginTop: 8 }} onClick={() => saveLogo(null)}>Remove Logo</button>}
            </div>
          </div>
        </div>
      )}

      {tab === "rooms" && (
        <div>
          <div style={styles.card}>
            <h2 style={styles.h2}>{editingRoom ? "Edit Room" : "Add New Room"}</h2>
            <div style={styles.grid2}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Room Name</label>
                <input style={styles.input} value={newRoom.name} onChange={e => setNewRoom(r => ({ ...r, name: e.target.value }))} placeholder="e.g. Board Room" />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Size</label>
                <input style={styles.input} value={newRoom.size} onChange={e => setNewRoom(r => ({ ...r, size: e.target.value }))} placeholder="e.g. 120 sqm" />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Max Capacity</label>
                <input style={styles.input} type="number" value={newRoom.capacity} onChange={e => setNewRoom(r => ({ ...r, capacity: e.target.value }))} placeholder="Max attendees" />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Rate (N$/person/hr)</label>
                <input style={styles.input} type="number" step="0.01" value={newRoom.rate} onChange={e => setNewRoom(r => ({ ...r, rate: e.target.value }))} placeholder="e.g. 150.00" />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Icon Emoji</label>
                <input style={styles.input} value={newRoom.icon} onChange={e => setNewRoom(r => ({ ...r, icon: e.target.value }))} placeholder="🏢" />
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button style={styles.btnPrimary} onClick={saveRoom}>{editingRoom ? "Update Room" : "Add Room"}</button>
              {editingRoom && <button style={styles.btnSecondary} onClick={() => { setEditingRoom(null); setNewRoom({ name: "", size: "", capacity: "", rate: "", icon: "🏢" }); }}>Cancel</button>}
            </div>
          </div>
          <div style={styles.card}>
            <h2 style={styles.h2}>Rooms</h2>
            <table style={styles.table}>
              <thead><tr>{["Icon", "Name", "Size", "Capacity", "Rate", "Actions"].map(h => <th key={h} style={styles.th}>{h}</th>)}</tr></thead>
              <tbody>
                {rooms.map(r => (
                  <tr key={r.id}>
                    <td style={styles.td}>{r.icon}</td>
                    <td style={styles.td}><strong>{r.name}</strong></td>
                    <td style={styles.td}>{r.size}</td>
                    <td style={styles.td}>{r.capacity}</td>
                    <td style={styles.td}>N${Number(r.rate).toFixed(2)}/person/hr</td>
                    <td style={styles.td}>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button style={styles.btnSecondary} onClick={() => { setEditingRoom(r); setNewRoom({ name: r.name, size: r.size, capacity: r.capacity, rate: r.rate, icon: r.icon }); }}>Edit</button>
                        <button style={styles.btnDanger} onClick={() => deleteRoom(r.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "users" && (
        <div>
          <div style={styles.card}>
            <h2 style={styles.h2}>{editingUser ? "Edit User" : "Add New User"}</h2>
            <div style={styles.grid2}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Full Name</label>
                <input style={styles.input} value={newUser.name} onChange={e => setNewUser(u => ({ ...u, name: e.target.value }))} />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Email</label>
                <input style={styles.input} type="email" value={newUser.email} onChange={e => setNewUser(u => ({ ...u, email: e.target.value }))} />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Role</label>
                <select style={styles.select} value={newUser.role} onChange={e => setNewUser(u => ({ ...u, role: e.target.value }))}>
                  <option>Admin</option>
                  <option>Editor</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Password {editingUser && "(leave blank to keep)"}</label>
                <input style={styles.input} type="password" value={newUser.password} onChange={e => setNewUser(u => ({ ...u, password: e.target.value }))} />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Active</label>
                <select style={styles.select} value={newUser.active ? "Yes" : "No"} onChange={e => setNewUser(u => ({ ...u, active: e.target.value === "Yes" }))}>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button style={styles.btnPrimary} onClick={saveUser}>{editingUser ? "Update User" : "Add User"}</button>
              {editingUser && <button style={styles.btnSecondary} onClick={() => { setEditingUser(null); setNewUser({ name: "", email: "", role: "Editor", password: "", active: true }); }}>Cancel</button>}
            </div>
          </div>
          <div style={styles.card}>
            <h2 style={styles.h2}>System Users</h2>
            <table style={styles.table}>
              <thead><tr>{["Name", "Email", "Role", "Active", "Actions"].map(h => <th key={h} style={styles.th}>{h}</th>)}</tr></thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id}>
                    <td style={styles.td}><strong>{u.name}</strong>{u.id === currentUser?.id && <Tag bg="#E3F2FD" text="#1565C0"> (you)</Tag>}</td>
                    <td style={styles.td}>{u.email}</td>
                    <td style={styles.td}><Tag bg={u.role === "Admin" ? "#FFF3E0" : "#E8F5E9"} text={u.role === "Admin" ? "#E65C00" : "#2E7D32"}>{u.role}</Tag></td>
                    <td style={styles.td}>{u.active ? "✅" : "❌"}</td>
                    <td style={styles.td}>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button style={styles.btnSecondary} onClick={() => { setEditingUser(u); setNewUser({ name: u.name, email: u.email, role: u.role, password: "", active: u.active }); }}>Edit</button>
                        <button style={styles.btnDanger} onClick={() => deleteUser(u.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── LOGIN PAGE ───────────────────────────────────────────────────────────────

function LoginPage({ users, onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    const user = users.find(u => u.email === email && u.password === password && u.active);
    if (user) { onLogin(user); } else { setError("Invalid email or password."); }
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #E8F0FE 0%, #F0F4FF 100%)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ background: "#fff", borderRadius: 20, padding: 40, width: "100%", maxWidth: 400, boxShadow: "0 8px 40px rgba(26,115,232,0.15)" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>🏢</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: "#0D47A1" }}>RoomSync</div>
          <div style={{ fontSize: 14, color: "#6B7280" }}>Workspace Management Portal</div>
        </div>
        {error && <Alert type="error">{error}</Alert>}
        <div style={styles.formGroup}>
          <label style={styles.label}>Email Address</label>
          <input style={styles.input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>
        <div style={styles.formGroup}>
          <label style={styles.label}>Password</label>
          <input style={styles.input} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === "Enter" && handleLogin()} />
        </div>
        <button style={{ ...styles.btnPrimary, width: "100%", padding: "12px 20px", fontSize: 15 }} onClick={handleLogin}>Sign In</button>
        <div style={{ marginTop: 20, padding: 14, background: "#F8FAFF", borderRadius: 10, fontSize: 12, color: "#6B7280" }}>
          <strong>Demo accounts:</strong><br />
          Admin: admin@roomsync.na / admin123<br />
          Editor: editor@roomsync.na / editor123
        </div>
      </div>
    </div>
  );
}

// ─── CONFIRMED BOOKINGS (PUBLIC) ──────────────────────────────────────────────

function ConfirmedBookingsPage({ bookings, rooms }) {
  const confirmed = bookings.filter(b => b.status === "Confirmed").sort((a, b) => a.date?.localeCompare(b.date));
  return (
    <div>
      <h1 style={{ ...styles.h1, marginBottom: 8 }}>✅ Confirmed Bookings</h1>
      <p style={{ color: "#6B7280", marginBottom: 20 }}>View all confirmed room bookings to check availability.</p>
      <div style={styles.card}>
        <table style={styles.table}>
          <thead>
            <tr>{["Room", "Date", "Time", "Agency", "Attendees"].map(h => <th key={h} style={styles.th}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {confirmed.length === 0 ? (
              <tr><td colSpan={5} style={{ ...styles.td, textAlign: "center", color: "#9CA3AF" }}>No confirmed bookings yet.</td></tr>
            ) : confirmed.map(b => {
              const room = rooms.find(r => r.id === b.roomId);
              return (
                <tr key={b.id}>
                  <td style={styles.td}><span>{room?.icon} {room?.name}</span></td>
                  <td style={styles.td}>{b.date}</td>
                  <td style={styles.td}>{b.startTime} – {b.endTime}</td>
                  <td style={styles.td}>{b.agency}</td>
                  <td style={styles.td}>{b.attendees}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const { bookings, saveBookings, tickets, saveTickets, users, saveUsers, rooms, saveRooms, logo, saveLogo } = useLocalData();
  const [currentUser, setCurrentUser] = useState(null);
  const [page, setPage] = useState("home");
  const [calendarDayModal, setCalendarDayModal] = useState(null);

  const isPrivileged = currentUser && ["Admin", "Editor"].includes(currentUser.role);
  const isAdmin = currentUser?.role === "Admin";

  if (!currentUser && ["dashboard", "tickets-admin", "bookings", "reports", "settings"].includes(page)) {
    return <LoginPage users={users} onLogin={user => { setCurrentUser(user); }} />;
  }

  const navItems = [
    { id: "home", label: "🏠 Home" },
    { id: "book", label: "📝 Book a Room" },
    { id: "confirmed", label: "✅ Confirmed Bookings" },
    { id: "ticket", label: "🎫 Submit Ticket" },
    ...(isPrivileged ? [
      { id: "dashboard", label: "📊 Dashboard" },
      { id: "bookings", label: "📅 All Bookings" },
      { id: "tickets-admin", label: "🎫 Manage Tickets" },
      { id: "reports", label: "📈 Reports" },
    ] : []),
    ...(isAdmin ? [{ id: "settings", label: "⚙️ Settings" }] : []),
  ];

  return (
    <div style={styles.app}>
      <nav style={styles.nav}>
        <div style={styles.navBrand} onClick={() => setPage("home")}>
          {logo ? <img src={logo} alt="Logo" style={{ height: 36, objectFit: "contain" }} /> : <span style={{ fontSize: 26 }}>🏢</span>}
          <span>RoomSync</span>
        </div>
        <div style={styles.navLinks}>
          {navItems.map(n => (
            <button key={n.id} style={styles.navLink(page === n.id)} onClick={() => setPage(n.id)}>{n.label}</button>
          ))}
        </div>
        <div style={styles.navRight}>
          {currentUser ? (
            <>
              <span style={{ fontSize: 13, opacity: 0.9 }}>{currentUser.name}</span>
              <span style={styles.badge(currentUser.role === "Admin" ? "#E65C00" : "#2E7D32")}>{currentUser.role}</span>
              <button style={{ background: "rgba(255,255,255,0.15)", color: "#fff", border: "none", borderRadius: 6, padding: "5px 12px", cursor: "pointer", fontSize: 13 }} onClick={() => { setCurrentUser(null); setPage("home"); }}>Sign Out</button>
            </>
          ) : (
            <button style={{ background: "rgba(255,255,255,0.2)", color: "#fff", border: "1px solid rgba(255,255,255,0.3)", borderRadius: 6, padding: "5px 14px", cursor: "pointer", fontSize: 13 }} onClick={() => setPage("dashboard")}>Staff Login</button>
          )}
        </div>
      </nav>

      <div style={styles.page}>
        {page === "home" && (
          <div>
            <div style={{ marginBottom: 28 }}>
              <h1 style={{ ...styles.h1, fontSize: 32 }}>Welcome to RoomSync</h1>
              <p style={{ color: "#6B7280", fontSize: 16 }}>Your workspace booking & support management hub</p>
              <div style={{ display: "flex", gap: 10, marginTop: 16, flexWrap: "wrap" }}>
                <button style={styles.btnPrimary} onClick={() => setPage("book")}>📝 Book a Room</button>
                <button style={styles.btnSecondary} onClick={() => setPage("ticket")}>🎫 Submit a Ticket</button>
                <button style={styles.btnSecondary} onClick={() => setPage("confirmed")}>✅ View Availability</button>
              </div>
            </div>

            <div style={styles.grid3}>
              {rooms.map(r => (
                <div key={r.id} style={{ background: "#fff", borderRadius: 16, padding: 20, boxShadow: "0 1px 3px rgba(0,0,0,0.07)", borderTop: `4px solid ${r.accent}`, cursor: "pointer" }} onClick={() => setPage("book")}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>{r.icon}</div>
                  <div style={{ fontWeight: 700, fontSize: 16, color: "#1A1A2E" }}>{r.name}</div>
                  <div style={{ fontSize: 13, color: "#6B7280", marginTop: 4 }}>{r.size} · Up to {r.capacity} people</div>
                  <div style={{ fontSize: 14, color: r.accent, fontWeight: 600, marginTop: 8 }}>N${r.rate}/person/hr</div>
                </div>
              ))}
            </div>

            <BookingCalendar bookings={bookings} rooms={rooms} onDateClick={(date, dayBookings) => setCalendarDayModal({ date, bookings: dayBookings })} />

            {calendarDayModal && (
              <Modal title={`Bookings on ${calendarDayModal.date}`} onClose={() => setCalendarDayModal(null)}>
                {calendarDayModal.bookings.length === 0 ? (
                  <Alert type="success">No bookings on this day — it's available!</Alert>
                ) : calendarDayModal.bookings.map(b => {
                  const room = rooms.find(r => r.id === b.roomId);
                  return (
                    <div key={b.id} style={{ padding: "12px 0", borderBottom: "1px solid #F3F4F6" }}>
                      <div style={{ fontWeight: 600 }}>{room?.icon} {room?.name}</div>
                      <div style={{ fontSize: 13, color: "#6B7280" }}>{b.startTime}–{b.endTime} · {b.attendees} attendees · {b.agency}</div>
                      <Tag bg={STATUS_COLORS[b.status]?.bg} text={STATUS_COLORS[b.status]?.text}>{b.status}</Tag>
                    </div>
                  );
                })}
                <button style={{ ...styles.btnPrimary, marginTop: 16 }} onClick={() => { setCalendarDayModal(null); setPage("book"); }}>Book for a Different Time</button>
              </Modal>
            )}
          </div>
        )}

        {page === "book" && (
          <BookingForm rooms={rooms} bookings={bookings} onSubmit={b => saveBookings([...bookings, b])} currentUser={currentUser} />
        )}

        {page === "confirmed" && <ConfirmedBookingsPage bookings={bookings} rooms={rooms} />}

        {page === "ticket" && (
          <TicketForm onSubmit={t => saveTickets([...tickets, t])} users={users} />
        )}

        {page === "dashboard" && isPrivileged && (
          <Dashboard bookings={bookings} tickets={tickets} rooms={rooms} />
        )}

        {page === "bookings" && isPrivileged && (
          <BookingsPage bookings={bookings} saveBookings={saveBookings} rooms={rooms} currentUser={currentUser} />
        )}

        {page === "tickets-admin" && isPrivileged && (
          <TicketsPage tickets={tickets} saveTickets={saveTickets} users={users} currentUser={currentUser} />
        )}

        {page === "reports" && isPrivileged && (
          <ReportsPage bookings={bookings} tickets={tickets} rooms={rooms} />
        )}

        {page === "settings" && (
          <SettingsPage users={users} saveUsers={saveUsers} rooms={rooms} saveRooms={saveRooms} logo={logo} saveLogo={saveLogo} currentUser={currentUser} />
        )}
      </div>
    </div>
  );
}
